
import streamlit as st
import matplotlib.pyplot as plt
import random

st.set_page_config(page_title="Bot Analyse Crash", layout="centered")

st.title("🎰 Analyseur Intelligent du Jeu Crash")
st.markdown("Simule ou colle un historique de cotes pour recevoir une estimation intelligente.")

# Entrée de l'utilisateur
default_values = ", ".join(str(round(random.uniform(1.0, 10.0), 2)) for _ in range(50))
input_text = st.text_area("📥 Entre ici l'historique des crashs (séparés par des virgules)", value=default_values)

# Traitement des données
try:
    historique = [float(x.strip()) for x in input_text.split(",") if x.strip()]
    if len(historique) < 10:
        st.warning("Merci d'entrer au moins 10 valeurs.")
    else:
        crashs_bas = [x for x in historique if x < 1.5]
        crashs_moyens = [x for x in historique if 1.5 <= x < 2.0]
        crashs_hauts = [x for x in historique if x >= 2.0]

        taux_bas = len(crashs_bas) / len(historique)
        taux_moyens = len(crashs_moyens) / len(historique)
        taux_hauts = len(crashs_hauts) / len(historique)

        # Estimation simple
        if taux_bas > 0.5:
            estimation = "🎯 **Haute probabilité que la prochaine cote soit > 2.0x** (après de nombreux crashs bas)"
        elif taux_hauts > 0.5:
            estimation = "⚠️ **Risque élevé de crash < 1.5x** (après de nombreux crashs hauts)"
        else:
            estimation = "📊 **Prochaine cote probablement entre 1.5x et 2.0x** (tendance équilibrée)"

        # Affichage
        st.subheader("📈 Graphique des crashs")
        fig, ax = plt.subplots()
        ax.plot(historique, marker='o', linestyle='-', color='blue')
        ax.axhline(1.5, color='red', linestyle='--', label='1.5x')
        ax.axhline(2.0, color='green', linestyle='--', label='2.0x')
        ax.set_title("Historique des cotes")
        ax.set_xlabel("Manche")
        ax.set_ylabel("Cote")
        ax.legend()
        st.pyplot(fig)

        st.subheader("🔍 Analyse Statistique")
        st.write(f"- Cotes < 1.5x : **{taux_bas * 100:.1f}%**")
        st.write(f"- Cotes entre 1.5x et 2.0x : **{taux_moyens * 100:.1f}%**")
        st.write(f"- Cotes ≥ 2.0x : **{taux_hauts * 100:.1f}%**")

        st.subheader("💡 Recommandation")
        st.markdown(estimation)

except ValueError:
    st.error("❌ Erreur de format : Assure-toi que les cotes sont bien séparées par des virgules.")
